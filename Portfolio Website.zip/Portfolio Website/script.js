function toggleMenu() {
    document.querySelector("nav ul").classList.toggle("active");
}
